from   telebot        import    types     as    ty
from   datetime       import    datetime  as    dt
import telebot        as        tg
import sqlite3        as        sql3
import hashlib        as        hash
import threading
import time
import os
ADMIN_KEY = "80&+1!KK#t_c/zVa"

#Create Bot and Add TOKEN
BOT_TOKEN = "7399585156:AAHZ1p219hn2agQ79qbULlcOwNtqTzCeJu4"
BOT = tg.TeleBot(token=BOT_TOKEN)


def clear_admins():
    global SQL_ADMIN, CURSOR_ADMIN
    try:
        SQL_ADMIN = sql3.connect("./DATA_ADMIN.DB")
        CURSOR_ADMIN = SQL_ADMIN.cursor()
        CURSOR_ADMIN.execute("DELETE  FROM admins")
        SQL_ADMIN.commit()
    except Exception as e:
        print(f"Ошибка при очистке таблицы admins: {e}")
    finally:
        CURSOR_ADMIN.close()
        SQL_ADMIN.close()
        return print("Список админов удален!")


#Connect to sql databases
translete = str.maketrans("","",")(,][")
try:
    SQL = sql3.connect("./DATA.DB")
    CURSOR = SQL.cursor()
    CURSOR.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(20) NOT NULL,
            password VARCHAR(50) NOT NULL,
            salt TEXT)''')
    
    SQL.autocommit = False
    SQL.commit()
    CURSOR.execute("SELECT COUNT(*) FROM users")
    column_info_users = str(CURSOR.fetchall()).translate(translete)
    column_count_users = int(column_info_users)
    counter_users = column_count_users
    print(f"Количество пользователей: {column_count_users}")
    SQL.commit()
except Exception as e:
    print(f"Ошибка при подключении к базе данных: {e}")
finally:
    CURSOR.close()
    SQL.close()

###ADMIN SQL
try:
    SQL_ADMIN = sql3.connect("./DATA_ADMIN.DB")
    CURSOR_ADMIN = SQL_ADMIN.cursor()
    CURSOR_ADMIN.execute('''
        CREATE TABLE IF NOT EXISTS admins (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          chat_id TEXT UNIQUE NOT NULL
        )''')
    SQL_ADMIN.autocommit = False
    SQL_ADMIN.commit()
    CURSOR_ADMIN.execute("SELECT COUNT(*) FROM admins")
    column_info_admins = str(CURSOR_ADMIN.fetchall()).translate(translete)
    column_count_admins = int(column_info_admins)
    SQL_ADMIN.commit()
except Exception as e:
    print(e)
finally:
    print(f"Количество админов: {column_count_admins}")
    CURSOR_ADMIN.close()
    SQL_ADMIN.close()


#Function and variables without use telebot:
def check_time(): 
  while True:
    if dt.now().hour == 23 and dt.now().minute == 59: 
        clear_admins()
        time.sleep(60)
    else:
        time.sleep(10)
    #RUN IN THE END OF PROGRAM
Hello_text = """
Твой единомышленник в мире программирования!
Этот бот постарается помочь разобраться в программировании вместе с джуном(сам разбирается не очень)   :) 
•📚Полезные статьи: Изучайте статьи на актуальные темы, от основ до продвинутых техник (Type/Java Script; Python).
•💡Собственные проекты: Узнай о наших проектах и почерпни вдохновение для собственных, помогай решать проблемы и исправляй свои!
•🛒Магазин: Скоро здесь появятся интересные товары для программистов и не только..."""
Fib_text = """import timeit
def fibonacci_iterative(n):
    a, b = 0, 1
    for i in range(n):
        a, b = b, a + b
    return 0

# Измеряем время выполнения итеративной функции
elapsed_time_iterative = timeit.timeit(lambda: fibonacci_iterative(1_500_000), number=1)
print(f"Время выполнения: {elapsed_time_iterative:.2f} секунд")
f = input()

Скопируй код и проверь, за какое время твой пк сможет пересчитать по порядку полторамиллиона раз последовательность Фибоначчи!"""
name_user = None



#MULTI_FUNCTION

#MENU
def Menu(message):
    keyboard = ty.ReplyKeyboardMarkup(resize_keyboard=True) 
    button_file = ty.KeyboardButton("Получить файл")
    button_login = ty.KeyboardButton("Зарегистрироваться")
    button_logout = ty.KeyboardButton("Назад")
    keyboard.row(button_file, button_login)
    keyboard.add(button_logout)
    BOT.send_message(message.chat.id, "Выберите действие:", reply_markup=keyboard)

#SEND FILES
def send_zip_file(zip_path: str, chat_id: int):
    try:
        with open(zip_path, "rb") as zip_file:
            BOT.send_document(chat_id, zip_file, caption="Вот ваш ZIP-архив!")
    except FileNotFoundError:
        BOT.send_message(chat_id, "Файл не найден. Повторите попытку позже.")



#LOGIN
def register_user(message):
    global name_user
    name_user = message.text
    if len(name_user) >= 30:
        BOT.send_message(message.chat.id, "Имя слишком длинное, повторите попытку")
    BOT.send_message(message.chat.id, "Придумайте пароль:")
    BOT.register_next_step_handler(message, save_password)

def save_password(message):
    global counter_users, column_count_admins, name_user
    password_user = message.text
    if len(password_user) >= 30:
        BOT.send_message(message.chat.id, "Пароль слишком длинный, повторите попытку")
    # ADMIN?
    if name_user == "ADMIN" and password_user == ADMIN_KEY:
        BOT.send_message(message.chat.id, "Вы вошли как админ")
        SQL_ADMIN = sql3.connect("./DATA_ADMIN.DB")
        CURSOR_ADMIN = SQL_ADMIN.cursor()
        try:
            CURSOR_ADMIN.execute("INSERT INTO admins (chat_id) VALUES (?)", (message.chat.id,))
            SQL_ADMIN.commit()
        except sql3.Error as e:
            print(f"Ошибка при добавлении админа в базу данных: {e}")
        finally:
            CURSOR_ADMIN.close()
            SQL_ADMIN.close()
            column_count_admins += 1
            print(f"Кто-то вошел как админ, сейчас их {column_count_admins}")
            keyline_ad = ty.ReplyKeyboardMarkup(resize_keyboard=True)
            button_back_ad = ty.InlineKeyboardButton("Назад")
            keyline_ad.add(button_back_ad)
            BOT.send_message(message.chat.id, "Регистрация админа окончена", reply_markup=keyline_ad)
            return 0
        
    SQL = sql3.connect("./DATA.DB")
    CURSOR = SQL.cursor()
    # Generation salt
    salt = os.urandom(16).hex()
    hashed_password = hash.sha256((salt + password_user).encode()).hexdigest()
    # USER
    try:
        CURSOR.execute(f"INSERT INTO users (name, password, salt) VALUES (?, ?, ?)", (name_user, hashed_password, salt))
        SQL.commit()
    except sql3.IntegrityError:
             BOT.send_message(message.chat.id, "Ошибка пароля, попробуйте другой")
    except Exception as e:
        print(f"Ошибка при добавлении пользователя в базу данных: {e}")
    finally:
        CURSOR.close()
        SQL.close()
        counter_users += 1
        keyline = ty.ReplyKeyboardMarkup(resize_keyboard=True)
        button_logout = ty.InlineKeyboardButton("Список всех пользователей")
        button_back = ty.InlineKeyboardButton("Назад")
        keyline.row(button_back, button_logout)
        BOT.send_message(message.chat.id, "Регистрация окончена", reply_markup=keyline)
        print(f"Новый пользователь зарегистрировался! Всего зарегистрированнно: {counter_users}")

#GET from DATABASE
def List_users(message):
    global CURSOR, SQL
    SQL = sql3.connect("./DATA.DB")
    CURSOR = SQL.cursor()
    CURSOR.execute('''
    SELECT * FROM users
''')
    users = CURSOR.fetchall()
    CURSOR.close()
    SQL.close()
    info = ""
    for el in users:
        info += f"Имя:{el[1]}\n Пароль:{el[2]}\n \n Соль:{el[3]}\n \n"
    BOT.send_message(message.chat.id, f"<b>{info}</b>", parse_mode = "html")



#Basic functions
@BOT.message_handler(commands=["start"])
def Main(message):
    BOT.send_message(message.chat.id, f"<b>Привет, </b>{message.from_user.first_name}!{Hello_text}", parse_mode="html")
    Menu(message)


@BOT.message_handler(commands=["web"])
def Go_site(message):
    Buttons_to_web = ty.InlineKeyboardMarkup()
    Btn_web1 = ty.InlineKeyboardButton("Перейти на сайт!", url="https://slerrick.github.io/WebSite3/")
    Btn_web2 = ty.InlineKeyboardButton("На всякий случай...", callback_data="fib")  
    Buttons_to_web.row(Btn_web1, Btn_web2)
    BOT.send_message(message.chat.id, "А вот и мой первый сайт 😊", reply_markup=Buttons_to_web)


@BOT.message_handler(content_types=["photo"])
def Answer_to_file(chatick):
    BOT.reply_to(chatick, "Отличный файл! Жаль, что пока я не могу работать с ним(")


@BOT.message_handler(commands=["admin"])
def Admin(message):
    global SQL_ADMIN, CURSOR_ADMIN
    try:
        SQL_ADMIN = sql3.connect("./DATA_ADMIN.DB")
        CURSOR_ADMIN = SQL_ADMIN.cursor()
        CURSOR_ADMIN.execute("SELECT chat_id FROM admins")
        SQL.commit()
        info_admin_id = CURSOR_ADMIN.fetchall()
    except Exception as e:
        print(e)
    finally:
        print(info_admin_id)
        CURSOR_ADMIN.close()
        SQL_ADMIN.close()
        print("Предоставлены права админа")

@BOT.message_handler()
def on_click(message):
    if message.text == "Получить файл":
        BOT.send_message(message.chat.id, "Подождите...")
        send_zip_file("./javascript-snakes-master.zip", message.chat.id)
    elif message.text == "Зарегистрироваться":
        BOT.send_message(message.chat.id, "Введите имя пользователя:")
        BOT.register_next_step_handler(message, register_user)
    elif message.text == "Назад":
        Menu(message)
    elif message.text == "Список всех пользователей":
        List_users(message)


@BOT.callback_query_handler(func=lambda call: True or call)
def Call_BOT(call):
    if call.data == "fib":
        BOT.send_message(call.message.chat.id, Fib_text)



#END_PROGRAM
threading.Thread(target=check_time).start()
BOT.polling(non_stop=True)